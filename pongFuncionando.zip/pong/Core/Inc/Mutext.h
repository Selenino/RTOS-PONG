/*
 * Mutext.h
 *
 *  Created on: Dec 11, 2025
 *      Author: Equipo
 */

#ifndef INC_MUTEXT_H_
#define INC_MUTEXT_H_

#include "App_Types.h"
#include "Task.h"
#include "Queue.h"




#define MUTEX_BASE_ERR              0x0400

#define MUTEX_OK                    0
#define MUTEX_ERR_NULL_PARAM        MUTEX_BASE_ERR | 0x00FF
#define MUTEX_ERR_EMPTY             MUTEX_BASE_ERR | 0x00FE
#define SCHEDULLER_ERR_WRONG_PARAM	   SCHEDULLER_BASE_ERR | 0x00FD


typedef struct{
	u8 Busy;
	QueueHandler_t WaitQueue;
}MutexHandler_t, * MutexHandler_t_ptr;


u16 Mutext_Init(MutexHandler_t_ptr Mutex);
u16 Mutex_Take(MutexHandler_t_ptr Mutex);
u16 Mutex_GIVE(MutexHandler_t_ptr Mutex);


#endif /* INC_MUTEXT_H_ */
