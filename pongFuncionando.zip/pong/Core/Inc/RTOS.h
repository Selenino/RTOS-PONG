/*
 * RTOS.h
 *
 *  Created on: Oct 5, 2025
 *      Author: Equipo
 */

#ifndef INC_RTOS_H_
#define INC_RTOS_H_

#include "App_Types.h"
#include "Task.h"
#include "Portable.h"
#include "RTOS_Defines.h"
#include "Queue.h"
#include "Scheduler.h"

#define RTOS_CreateTask    Task_CreateTask
#define RTOS_Delay         Task_Delay


extern volatile u8 RTOS_Started;


u16 RTOS_Init(void);
void RTOS_Start(void);
#endif /* INC_RTOS_H_ */
