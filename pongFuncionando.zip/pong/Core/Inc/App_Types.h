#ifndef INC_APPTYPES_H_
#define INC_APPTYPES_H_
// =======================
// TIPOS ENTEROS CON SIGNO
// =======================
typedef signed char s8;    // 8 bits con signo
typedef signed short s16;   // 16 bits con signo
typedef signed int s32;   // 32 bits con signo
typedef signed long s64;   // 64 bits con signo

typedef signed char *ds8;    // 8 bits con signo
typedef signed short *ds16;   // 16 bits con signo
typedef signed int *ds32;   // 32 bits con signo
typedef signed long * ds64;   // 64 bits con signo


typedef unsigned char      u8;    // 8 bits sin signo
typedef unsigned short     u16;   // 16 bits sin signo
typedef unsigned int       u32;   // 32 bits sin signo
typedef unsigned long  u64;   // 64 bits sin signo

typedef unsigned char   *   pu8;    // 8 bits sin signo
typedef unsigned short   *  pu16;   // 16 bits sin signo
typedef unsigned int    *   pu32;   // 32 bits sin signo
typedef unsigned long  * pu64;   // 64 bits sin signo
// ================
// TIPOS FLOTANTES
// ================
typedef float f;   // 32 bits
typedef double fd;   // 64 bits
typedef float *pd;  // 80-128 bits (depende del compilador)
typedef double *pf;
typedef void v;
typedef void *pv;
#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE   0
#endif
#endif /* INC_APPTYPES_H_ */
