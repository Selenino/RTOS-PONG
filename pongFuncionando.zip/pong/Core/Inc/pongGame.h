/*
 * pongGame.h
 *
 *  Created on: Dec 10, 2025
 *      Author: Equipo
 */

#ifndef INC_PONGGAME_H_
#define INC_PONGGAME_H_


#include <stdint.h>
#include "main.h"

// Variables externas para las barras (definidas en pongGame.c)
extern int8_t x1;
extern int8_t y1_top;
extern int8_t y1_bottom;

extern int8_t x2;
extern int8_t y2_top;
extern int8_t y2_bottom;
void Ball_Init(void);
void Ball_Update(void);
void Game_Render(void);
void draw_lines(void);
void Update_Paddle(int8_t *y_top, int8_t *y_bottom, uint16_t pin_up, uint16_t pin_down);
void Paddles_Update(void);

void Buzzer_Activate(void);

void Buzzer_Deactivate(void);

void Buzzer_Update(void);




#endif /* INC_PONGGAME_H_ */
