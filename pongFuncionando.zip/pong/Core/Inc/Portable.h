/*
 * Portable.h
 *
 *  Created on: Oct 3, 2025
 *      Author: Equipo
 */


#include "App_Types.h"
#ifndef INC_PORTABLE_H_
#define INC_PORTABLE_H_

#define RTOS_SYSTEM_CLOCK 64000000
#define RTOS_TICK_CLOCK   1000

void Port_EnableInterrupts(void);
void Port_DisableInterrupts(void);
void Port_InitTickTimer(void);
u32 Port_InitStack(pu32 Stack, u32 StackSize, pv Function);
void Port_RestoreFirstContext(u32 Sp);
void Port_SoftwareInterrupt(void);
u32 Port_GetSystemTick(void);
#endif /* INC_PORTABLE_H_ */
