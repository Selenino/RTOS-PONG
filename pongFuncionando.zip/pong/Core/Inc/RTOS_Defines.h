/*
 * RTOS_Defines.h
 *
 *  Created on: Oct 4, 2025
 *      Author: Equipo
 */

#ifndef INC_RTOS_DEFINES_H_
#define INC_RTOS_DEFINES_H_

#define RTOS_SYSTEM_CLOCK 		64000000
#define RTOS_TICK_CLOCK   		1000
#define  RTOS_MIN_STACK_SIZE 	512
#define RTOS_SYSTEM_PRIORITIES   16
#define RTOS_MIN_PRIORITY 		RTOS_SYSTEM_PRIORITIES-1

#endif /* INC_RTOS_DEFINES_H_ */
