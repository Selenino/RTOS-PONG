/*
 * Task.h
 *
 *  Created on: Oct 4, 2025
 *      Author: Equipo
 */

#ifndef INC_TASK_H_
#define INC_TASK_H_




#include "App_Types.h"
#include "RTOS_Defines.h"
#include "Queue.h"

#ifndef NULL
#define NULL ((void*)0)
#endif

#define TASK_BASE_ERR              0x0200

#define TASK_OK                    0
#define TASK_ERR_NULL_PARAM        TASK_BASE_ERR | 0x00FF
#define TASK_ERR_EMPTY             TASK_BASE_ERR | 0x00FE
#define TASK_ERR_WRONG_PARAM	   TASK_BASE_ERR | 0x00FD

typedef void (*TaskFunction)(void); //callback a la función

typedef enum{
	ST_READY =0,
	ST_RUNNING,
	ST_BLOCKED

}TaskStatus_t,*TaskStatus_t_ptr;


typedef struct{
	char *Name;
	u8    Id;
	TaskFunction Function;
	u8 Priority;
	pu32 Stack;
	u32 StackSize;
	u32 DelayTime;
	u32 Actual_StackPointer;
	TaskStatus_t Status;
	QueueElement_t QElement;

}TaskControlBlock_t, *TaskControlBlock_t_ptr;

u16 Task_Init(void);

u16 Task_CreateTask(TaskControlBlock_t_ptr TCB, char *Name, u8 Id, u8 Priority, pu32 Stack, u32 StackSize, TaskFunction );

u16 Task_CreateIdleTask(void);

u8  Task_Started(void);

TaskControlBlock_t_ptr TaskGetIdleTask(void);

u16 Task_Delay(u32 Ticks);

#endif /* INC_TASK_H_ */
