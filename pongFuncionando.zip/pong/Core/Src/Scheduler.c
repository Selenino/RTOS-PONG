/*
 * Scheduler.c
 *
 *  Created on: Oct 4, 2025
 *      Author: Equipo
 */
#include "App_Types.h"
#include "Task.h"
#include "Portable.h"
#include "RTOS_Defines.h"
#include "Queue.h"
#include "Scheduler.h"



QueueHandler_t SchedullerReadyTasks[RTOS_SYSTEM_PRIORITIES];
TaskControlBlock_t_ptr ActualTask=NULL;

 u16 Scheduller_SetTaskReady(TaskControlBlock_t_ptr Task);
u32 Scheduller_GetNextTask(u32 ActualStack);


u16 Scheduller_Init(){
	ActualTask=NULL;
	u16 Res=SCHEDULLER_ERR_EMPTY;
	for(int i=0; i<RTOS_SYSTEM_PRIORITIES; i++){
		Res=Queue_Init(&SchedullerReadyTasks[i]);
		if(Res){
			break;
		}
	}
	return Res;
}


TaskControlBlock_t_ptr Scheduller_GetActualTask(void){
	return ActualTask;
}

u16 Scheduller_SetTaskReady(TaskControlBlock_t_ptr Task){
	u16 Res=SCHEDULLER_ERR_NULL_PARAM;
	if(Task!=NULL){
		Task->Status=ST_READY;
		if(Task->Priority <RTOS_SYSTEM_PRIORITIES){
			Res=Queue_Enqueue(&SchedullerReadyTasks[Task->Priority], &Task->QElement, Task);
		}
	}
	return Res;
}

u32 Scheduller_GetNextTask(u32 ActualStack){
	if(ActualStack!=(u32)NULL)
	{
		if(ActualTask!=NULL)
		{
			ActualTask->Actual_StackPointer=ActualStack;
			if(ActualTask->Id!=0){

				if(ActualTask->Status==ST_RUNNING){

					Scheduller_SetTaskReady(ActualTask);

				}
			}
			else{
				ActualTask->Status=ST_READY;
			}
		}
	}
	ActualTask=NULL;
	for(int i=0; i<RTOS_SYSTEM_PRIORITIES; i++){
		if(Queue_GetCount(&SchedullerReadyTasks[i])){

			if (Queue_Dequeue(&SchedullerReadyTasks[i],(pv*) &ActualTask)==QUEUE_OK){
				if(ActualTask!=NULL){
					break;
				}
			}
		}
	}
	if(ActualTask==NULL){
		ActualTask=TaskGetIdleTask();
	}
	ActualTask->Status=ST_RUNNING;
	return ActualTask->Actual_StackPointer;
}
