#include "pongGame.h"
#include <ssd1306.h>
#include "Mutext.h"
#include <stdint.h>
#include "main.h"

#define SCREEN_W 128
#define SCREEN_H 64
#define BALL_R   2
#define PADDLE_SPEED 3

#define PADDLE_HEIGHT    8
#define PADDLE_MIN_Y     5
#define PADDLE_MAX_Y     (SCREEN_H - PADDLE_HEIGHT - 5)


#define BTN_RIGHT_UP      GPIO_PIN_12    // PB12 - Arriba barra derecha
#define BTN_RIGHT_DOWN    GPIO_PIN_13    // PB13 - Abajo barra derecha
#define BTN_LEFT_UP       GPIO_PIN_14    // PB14 - Arriba barra izquierda
#define BTN_LEFT_DOWN     GPIO_PIN_15    // PB15 - Abajo barra izquierda
#define BUZZER_PIN        GPIO_PIN_11    // PB11 - Buzzer

#define BUZZER_DURATION   30


int8_t x1 = 5;
int8_t y1_top = 20;
int8_t y1_bottom = 35;

int8_t x2 = 123;
int8_t y2_top = 20;
int8_t y2_bottom = 35;


typedef struct {
    int16_t x;
    int16_t y;
    int8_t  vx;
    int8_t  vy;
} Ball_t;

Ball_t ball;


static uint32_t buzzer_timer = 0;
static uint8_t buzzer_active = 0;


static GPIO_PinState Read_Button(uint16_t pin)
{
    return HAL_GPIO_ReadPin(GPIOB, pin);
}


void Buzzer_Activate(void)
{
    if (!buzzer_active) {  // Solo activar si no está activo
        HAL_GPIO_WritePin(GPIOB, BUZZER_PIN, GPIO_PIN_SET);
        buzzer_timer = BUZZER_DURATION / 20;  // Convertir ms a ciclos de 20ms
        buzzer_active = 1;
    }
}


void Buzzer_Deactivate(void)
{
    HAL_GPIO_WritePin(GPIOB, BUZZER_PIN, GPIO_PIN_RESET);
    buzzer_timer = 0;
    buzzer_active = 0;
}


void Buzzer_Update(void)
{
    if (buzzer_active && buzzer_timer > 0) {
        buzzer_timer--;
    } else if (buzzer_active && buzzer_timer == 0) {
        Buzzer_Deactivate();
    }
}


void Update_Paddle(int8_t *y_top, int8_t *y_bottom, uint16_t pin_up, uint16_t pin_down)
{
    GPIO_PinState btn_up = Read_Button(pin_up);
    GPIO_PinState btn_down = Read_Button(pin_down);


    if (btn_up == GPIO_PIN_SET)
    {
        *y_top -= PADDLE_SPEED;
        *y_bottom -= PADDLE_SPEED;
    }


    if (btn_down == GPIO_PIN_SET)
    {
        *y_top += PADDLE_SPEED;
        *y_bottom += PADDLE_SPEED;
    }


    if (*y_top < PADDLE_MIN_Y)
    {
        *y_top = PADDLE_MIN_Y;
        *y_bottom = PADDLE_MIN_Y +PADDLE_HEIGHT+ PADDLE_HEIGHT;
    }

    if (*y_bottom > (SCREEN_H - PADDLE_MIN_Y))
    {
        *y_bottom = SCREEN_H - PADDLE_MIN_Y;
        *y_top = *y_bottom - PADDLE_HEIGHT-PADDLE_HEIGHT;
    }
}


void Paddles_Update(void)
{
    Update_Paddle(&y1_top, &y1_bottom, BTN_LEFT_UP, BTN_LEFT_DOWN);
    Update_Paddle(&y2_top, &y2_bottom, BTN_RIGHT_UP, BTN_RIGHT_DOWN);
}

void Ball_Init(void) {
    ball.x = SCREEN_W / 2;
    ball.y = SCREEN_H / 2;
    ball.vx = 3;
    ball.vy = 3;
}

void Ball_Update(void) {

    ball.x += ball.vx;
    ball.y += ball.vy;

    // Salida por izquierda
    if (ball.x < 5) {
        ball.x = SCREEN_W / 2;
        ball.y = SCREEN_H / 2;
        ball.vx = 2;
        ball.vy = -2;
        Buzzer_Activate();
        return;
    }

    // Salida por la derecha
    if (ball.x > (SCREEN_W - 5)) {
        ball.x = SCREEN_W / 2;
        ball.y = SCREEN_H / 2;
        ball.vx = -2;
        ball.vy = 2;
        Buzzer_Activate();
        return;
    }

    // Rebote arriba
    if (ball.y <= 5) {
        ball.y = 5;
        ball.vy = -ball.vy;

    }

    // Rebote abajo
    if (ball.y >= (SCREEN_H - BALL_R)) {
        ball.y = SCREEN_H - BALL_R;
        ball.vy = -ball.vy;

    }

    // Colisión con barra izquierda
    if (ball.x <= x1 + 2 &&
            ball.y >= y1_top &&
            ball.y <= y1_bottom &&
            ball.vx < 0) {
            ball.vx = -ball.vx;
            ball.x = x1 + 3;
            Buzzer_Activate();
            return;
        }

    // Colisión con barra derecha
    if (ball.x >= x2 - 2 &&
        ball.y >= y2_top &&
        ball.y <= y2_bottom &&
        ball.vx > 0) {
        ball.vx = -ball.vx;
        ball.x = x2 - 3;
        Buzzer_Activate();
        return;
    }
}

void Game_Render(void) {
    ssd1306_Fill(Black);
    ssd1306_FillCircle(ball.x, ball.y, 2, White);
    draw_lines();
    Buzzer_Update();
    ssd1306_UpdateScreen();
}

void draw_lines(void) {
    // Barra izquierda
    ssd1306_Line(x1, y1_top, x1, y1_bottom, White);

    // Barra derecha
    ssd1306_Line(x2, y2_top, x2, y2_bottom, White);

    ssd1306_UpdateScreen();
}
