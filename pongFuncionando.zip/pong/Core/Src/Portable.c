/*
 * Portable.c
 *
 *  Created on: Oct 3, 2025
 *      Author: Equipo
 */


#include "App_Types.h"
#include "Portable.h"
#include "RTOS_Defines.h"
#include "RTOS.h"
#include "stm32f1xx.h"
#include "stm32f1xx_hal.h"

extern u32 Scheduller_GetNextTask(u32 ActualStack);

#define _enable_irq(){asm("cpsie i");}  //registros tomados del datasheet
#define _disable_irq(){asm("cpsid i");}


u32 PortNextedCounter=0; //esto cuenta cuántas veces han habido interrupciones
u32 Port_ActualStackPointer=0;

u32 Port_TickCounter=0;

u8 Index=0;
u32 TaskSP[2]={0, 0};



__attribute__ ((always_inline))static inline void Port_SaveContext(){
	__asm volatile("PUSH {LR}");
	__asm volatile("PUSH {R4-R11}");
	__asm volatile("MRS R0, MSP");
	__asm volatile("MOV %0, R0":"=r"(Port_ActualStackPointer));

}

__attribute__ ((always_inline))static inline void Port_RestoreContext(){

	__asm volatile("MOV R0, %0": :"r"(Port_ActualStackPointer));
	__asm volatile("MSR MSP, R0");
	__asm volatile("POP {R4-R11}");
	__asm volatile("POP {PC}");

}


void Port_EnableInterrupts(){
	if(PortNextedCounter){
		PortNextedCounter--;
	}

	if(!PortNextedCounter){
		_enable_irq(); //habilita las interrupciones
	}

}
void Port_DisableInterrupts(){
	if(PortNextedCounter){
		PortNextedCounter++;
		_disable_irq();
	}
}
//Aquí se crea un timer para manejar el tick del sistema (lleva la escala de tiempo del sistema)
//El registro de control se buscó en el datasheet
void Port_InitTickTimer(){
	pu32 pSTK_CTRL=(pu32)(0xE000E010);   //asociado al registro especial del sys tick
	pu32 pSTK_LOAD=(pu32)(0xE000E014);

	u32 TickCounterValue=(RTOS_SYSTEM_CLOCK/RTOS_TICK_CLOCK)-1;
	*pSTK_LOAD&=0xFF000000;
	*pSTK_LOAD|=TickCounterValue;
	*pSTK_CTRL|=(1<<2);
	*pSTK_CTRL|=(1<<1);
	*pSTK_CTRL|=(1<<0);

}


void Port_SoftwareInterrupt(void){
	pu32 pSCB_ICSR=(pu32)(0xE000ED04);
	*pSCB_ICSR|=(1<<28);
}


u32 Port_GetSystemTick(void){
	return Port_TickCounter;
}
u32 Port_InitStack(pu32 Stack, u32 StackSize, pv Function){
	Stack+=StackSize;
	Stack--;
	*Stack=0x01000000UL; //PSR
	Stack--;
	*Stack=(u32)((u32)Function & 0xFFFFFFFEUL); //PC
	*Stack|=0x00000001UL;
	Stack--;
	*Stack=(u32)((u32)Function & 0xFFFFFFFEUL); //LR
	*Stack|=0x00000001UL;
	Stack--;
	*Stack=0; 									//R12
	Stack--;
	*Stack=0;  //R3
	Stack--;
	*Stack=0;  //R2
	Stack--;
	*Stack=0;  //R1
	Stack--;
	*Stack=0;  //R0
	Stack--;
	*Stack=0XFFFFFFF9UL;  //LR DE LA INTERRUPCIÓN DEL EXCEC RETURN
	Stack--;
	*Stack=0; 									//R11
	Stack--;
	*Stack=0; 									//R10
	Stack--;
	*Stack=0; 									//R9
	Stack--;
	*Stack=0; 									//R8
	Stack--;
	*Stack=0; 									//R7
	Stack--;
	*Stack=0; 									//R6
	Stack--;
	*Stack=0; 									//R5
	Stack--;
	*Stack=0; 									//R4
	return (u32)Stack;
}

void Port_RestoreFirstContext(u32 Sp){
	Port_ActualStackPointer=Sp;
	__asm("MOV R0, %0": :"r"(Port_ActualStackPointer));
	__asm("MSR MSP, R0");
	__asm("POP {R4-R11}");
	__asm("POP {LR}");
	__asm("POP {R0-R3}");
	__asm("POP {R12}");
	__asm("POP {LR}");
	__asm("POP {LR}");
	__asm("POP {R10}");
	__asm("MSR PSR, R10");
	__asm("MOV R10, #0");  // EL # SIGNIFICA VALOR INMEDIATO
	__asm("BX  LR");

}

__attribute__((naked)) void SysTick_Handler(void)
{
	//HAL_IncTick();
	Port_SaveContext();
	Port_TickCounter++;
	Port_ActualStackPointer=Scheduller_GetNextTask(Port_ActualStackPointer);
	Port_RestoreContext();

	/*HAL_IncTick();
	if (!RTOS_Started)
		return;
	Port_TickCounter++;
	SCB->ICSR |= SCB_ICSR_PENDSVSET_Msk;*/

}

__attribute__((naked))void PendSV_Handler(void){
	Port_SaveContext();
	Port_ActualStackPointer=Scheduller_GetNextTask(Port_ActualStackPointer);
	Port_RestoreContext();


}
