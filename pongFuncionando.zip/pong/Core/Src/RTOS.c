/*
 * RTOS.c
 *
 *  Created on: Oct 5, 2025
 *      Author: Equipo
 */


#include "App_Types.h"
#include "Task.h"
#include "Portable.h"
#include "RTOS.h"
#include "RTOS_Defines.h"
#include "Queue.h"
#include "Scheduler.h"

u8 volatile RTOS_Started = 0;

u16 RTOS_Init(void){
	u16 Res=Scheduller_Init();
	if(Res==SCHEDULLER_OK){
		Res=Task_Init();
		if(Res==TASK_OK){
			Res=Task_CreateIdleTask();
		}
	}
	return Res;
}

void RTOS_Start(void){
	u32 FirstTask=Scheduller_GetNextTask(0);
	  Port_InitTickTimer();
	   //Port_DisableInterrupts();
	  Port_EnableInterrupts();
	  Port_RestoreFirstContext(FirstTask);
	  RTOS_Started=1;
}
